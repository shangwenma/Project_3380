function form_submit(form) {
    document.getElementById(form).submit();
}